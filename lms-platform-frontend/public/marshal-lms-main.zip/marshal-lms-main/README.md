Update: 29.06.2025 - Hey everyone! Part two was published two days ago and has a total length of 12 hours. I want to thank you all for supporting me and the channel. If you have any questions, just ping me on Discord or send me an email. Thanks, and enjoy your day! 🫶🏻

Update: 24.06.2025 - Part two is almost finished 6 hours have alredy been edited. this will be a 20+ hours video.

Hey everyone 👋

This is the repo for the Marshal-LMS video.
The full version of the code will be released this Tuesday when Part Two goes live.
If you need early access for any reason (e.g. XYZ), feel free to email me: jan@marshalcode.com

Thanks for supporting the channel —
now enjoy the video!

– Jan
